import PLSprite as PLS
import pygame as pg

pg.init()
l, a = (1050, 550)
tela = pg.display.set_mode((l, a))
run = True
spritesheet_primo_mario = pg.image.load('imagem/AHLH/primo_mario_andando.png')

spritesheet_primo_mario = PLS.FormatarSpriteSheet(spritesheet_primo_mario,
                                                  (300, 300),
                                                  100,
                                                  100,
                                                  PLS.AHLH,
                                                  9,
                                                  3,
                                                  (300, 300)).formatar()
print(spritesheet_primo_mario)
while run:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            run = False
    tela.fill((0, 0, 0))
    
    tela.blit(spritesheet_primo_mario, (0, 0))
    
    pg.display.flip()
