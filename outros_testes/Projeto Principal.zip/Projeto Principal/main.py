import pygame as pg
from PLSprite import Avatar, AHLV, C_cima, C_baixo, C_esquerda, C_direita

pg.init()
LARGURA, ALTURA = (1050, 550)
tela = pg.display.set_mode((LARGURA, ALTURA))
RUN = True

adao_spritesheet = pg.image.load('imagem/AHLV/adao_andando.png')

adao = Avatar(tela, adao_spritesheet, 0, 0, LARGURA//2, ALTURA//2, largura=100, altura=100, lado=AHLV, chave_lados=(C_cima, C_esquerda, C_baixo, C_direita), num_animacao_h=9, dimensao=(900, 400), animacao_h=True)

while RUN:
    for event in pg.event.get():
        if event.type == pg.QUIT or pg.key.get_pressed()[pg.K_LCTRL]:
            RUN = False
        # poder de invisibilidade
        if event.type == pg.KEYDOWN and event.key == pg.K_q:
            adao.set_avatar_visivel(False)
        elif event.type == pg.KEYUP and event.key == pg.K_q:
            adao.set_avatar_visivel(True)
    tela.fill((0, 0, 0))
    adao.atualizar()
    adao.controles((pg.K_w, pg.K_a, pg.K_s, pg.K_d))
    if not adao.get_acao():
        adao.set_imgx(0)
    adao.set_velocidade(0.2)
    pg.display.flip()
